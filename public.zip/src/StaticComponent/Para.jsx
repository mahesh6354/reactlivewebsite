import React from 'react'
import '../StaticComponent/para.css'
import { Link } from 'react-router-dom'
const Para = () => {
  return (
    <>
       <div className='a44e6186 ps-relative' style={{marginTop : "10px"}}>
       <div>
       <h3 className='_7bb331bc title' style={{marginTop: '16px',
        marginBottom: '24px'}}>
       THE LATEST</h3>
       <div className='first' style={{marginBottom:"40px"}}>
       <ul className='_299d570f'>
        <li className='_61f4c6c9'>
        <Link to="/" className='_921c660c' style={{cursor : "pointer"}}>
        The Best Electric Vehicle Chargers for Home</Link></li>
       </ul>
       <p className='a7e54c5a' to="/" style={{cursor : "pointer"}}>
       Yesterday</p>
       </div>
       <div className='first' style={{marginBottom:"40px"}}>
       <ul className='_299d570f'>
        <li className='_61f4c6c9'>
        <a to="/" className='_921c660c'>
        The Best Cheap Mattresses (Under $500)</a></li>
       </ul>
       <p className='a7e54c5a'>
       Yesterday</p>
       </div>
       <div className='first' style={{marginBottom:"40px"}}>
       <ul className='_299d570f'>
        <li className='_61f4c6c9'>
        <a to="/" className='_921c660c'>
        The Best Chromebooks</a></li>
       </ul>
       <p className='a7e54c5a'>
       Yesterday</p>
       </div>
       <div className='first' style={{marginBottom:"40px"}}>
       <ul className='_299d570f'>
        <li className='_61f4c6c9'>
        <a to="/" className='_921c660c'>
        How to Shop for a Used Laptop or Desktop PC</a></li>
       </ul>
       <p className='a7e54c5a'>
       Yesterday</p>
       </div> <div className='first' style={{marginBottom:"40px"}}>
       <ul className='_299d570f'>
        <li className='_61f4c6c9'>
        <a to="/" className='_921c660c'>
        The Best Lunch Boxes</a></li>
       </ul>
       <p className='a7e54c5a'>
       Yesterday</p>
       </div>
       <div className='first' style={{marginBottom:"40px"}}>
       <ul className='_299d570f'>
        <li className='_61f4c6c9'>
        <a to="/" className='_921c660c'>
        Everything New York Times Pop Critic Lindsay Zoladz Uses to Listen to Vinyl</a></li>
       </ul>
       <p className='a7e54c5a'>
       Yesterday</p>
       </div>
       </div>
       </div>
    </>
  )
}

export { Para } 
