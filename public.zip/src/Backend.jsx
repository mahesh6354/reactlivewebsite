// config.js
// localhost url
//const backendurl = 'http://192.168.1.15:8000';

// live server url
 const backendurl = 'http://137.184.35.255:8000';


export default backendurl;
