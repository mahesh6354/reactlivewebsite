import React from "react";
import {Routes, Route, Navigate } from 'react-router-dom'
import { Home } from './Component/Home'
import { AdminCate } from "./Admin/AdminCate";
import { Category } from "./Component/Category";
import { Post } from './Admin/Post'
import { Admin } from "./Admin/Admin";
import { AdminPost } from "./Admin/AdminPost";
import { Edit } from './Admin/Edit'
import { Policy } from "./Component/Policy";
import { Login } from "./Component/Login";
import { FirstCate } from "./Component/FirstCate";
import { CategoryPage } from "./Component/CategoryPage";
import { ErrorPage } from "./Component/ErrorPage";
import { SubcategoryPage } from "./Component/SubcategoryPage";
import { SearchPage } from "./Component/SearchPage";
import { ViewPost } from "./Admin/ViewPost";
import { AllPost } from './Component/AllPost'
import { TotalCardPost } from "./Component/TotalCardPost";
import { AdsComponent } from "./AdsComponent";
import { AdminPanel } from "./Admin/AdminPanel";
import { ScrollToTop } from "./Component/ScrollToTop";


const App = () => {
  return (
    <>
    
    <ScrollToTop />
   
    <Routes>
  
    <Route  exact path="/admin" element={<Admin />} />
    <Route exact path="/adminpanel" element={<AdminPanel />} />
    <Route exact path="/admincate" element={<AdminCate />} />
    <Route exact path="/viewpost" element = {<ViewPost />} />
    <Route exact path="/update/:id" element={<AdminPost />} />
    <Route exact path="/edit/:id" element={<Edit />} />

    <Route exact path="/post/:id" element= {<FirstCate />} />
    <Route exact path="/latestblog/:id" element= {<FirstCate />} />
    <Route  exact path="/" element={<Home />} />
    <Route  exact path="/category" element={<Category />} />
    <Route path="/Category/:id" element={<CategoryPage />} />
    <Route exact path="/subcatego ryPage/:id" element={<SubcategoryPage />} />
    <Route exact path="/errorPage" element={<ErrorPage />} />
    <Route element={<ErrorPage />} />
    <Route exact path="/allpost" element={<AllPost /> } />
    <Route exact path="/allpostcard" element={<TotalCardPost /> } />
    <Route  exact path="/posted" element={<Post />} />
    
   
    <Route exact path="/policy" element={ <Policy />} />
    <Route exact path="/loginuser" element={ <Login />} />
    <Route exact path="/search" element={<SearchPage />} />
    <Route exact path ='*' element = {<ErrorPage />} />
    <Route path='*' element= {<Navigate to="/" replace />} />
    
    </Routes>
    </>
  );
}

export { App };


