import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './header.css';
import { Link, useNavigate } from 'react-router-dom';
import backendurl from '../Backend';

const Header2 = () => {
  const [category, setCategory] = useState([]);
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const navigator = useNavigate();

  // const backendurl = 'http://192.168.1.15:8000';
  // //const backendurl = 'http://164.92.97.243:8000';

  const fetchAllBooks = async () => {
    try {
      const res = await axios.get(backendurl + '/getactivecategory');
      setCategory(res.data);
      console.log(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleSearchInputChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    navigator(`/search?q=${encodeURIComponent(search)}`);
    setSearch("");
  };

  const handleButtonClick = (id) => {
    const Cateid = id;
    console.log('category id is the', Cateid);
    navigate(`/Category/${Cateid}`);
  };

  const handleButtonClick1 = (id) => {
    const Subcateid = id;
    console.log('subcategory id is the', Subcateid);
    navigate(`/Category/${Subcateid}`);
  };

  useEffect(() => {
    fetchAllBooks();
  }, []);

  return (
    <div>
    <nav className="navbar navbar-expand-lg navbar-light  sticky-top" style={{backgroundColor : "#222"}}>
    <a className="navbar-brand" href="/" style={{fontSize: "34px",
    color: 'white',
      marginLeft: "1rem" }}>
      Codigo
    </a>
        <button
        style={{
          backgroundColor: '#d2d1d1',
         
        }}
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNavDropdown" style={{ flexDirection: 'column' }}>
          <ul className="nav shriti">
          <li className="nav-item _61361b4c" style={{ paddingTop: '4px' }}>
          <Link className='zss' to="/">HOME</Link>
        </li>
        
            {category.map((elem) => (
              <li className="nav-item _61361b4c" key={elem.id} >
                <div className="dropdown a6e85973">
                  <button
                  style={{
                    fontWeight: 'bolder',
                    fontSize: '21px',
                    color : "white"          
                  }}
                    className="btn main-tag a6e85973"
                    type="button"
                    id={`dropdown-${elem.id}`}
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    onClick={() => handleButtonClick(elem.id)}
                  >
                    {elem.name}
                  </button>
                  <ul className="dropdown-menu" aria-labelledby={`dropdown-${elem.id}`}>
                    {elem.subcategorylist.map((elem) => (
                      <li key={elem.id}>
                        <button className="dropdown-item .dropdown-item1 hover" onClick={() => handleButtonClick(elem.id)}>
                          {elem.name}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </div>
  );
  
};

export { Header2 };
