import React, { useEffect, useState } from 'react';
import img1 from '../img/codigologo.png'
import axios from 'axios';
import './header.css';
import { Link, useNavigate } from 'react-router-dom';
import backendurl from '../Backend';

const Header = () => {
  const [category, setCategory] = useState([]);
  const navigate = useNavigate();

  const [search, setSearch] = useState("");
  const navigator = useNavigate();



  const fetchAllBooks = async () => {
    try {
      const res = await axios.get(backendurl + '/getactivecategory');
      setCategory(res.data);
      console.log(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const handleSearchInputChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    navigator(`/search?q=${encodeURIComponent(search)}`);
    setSearch("");
  };

  const handleButtonClick = (id) => {
    const Cateid = id;
    console.log('category id is the', Cateid);
    navigate(`/Category/${Cateid}`);
  };

  const handleButtonClick1 = (id) => {
    const Subcateid = id;
    console.log('subcategory id is the', Subcateid);
    navigate(`/Category/${Subcateid}`);
  };

  useEffect(() => {
    fetchAllBooks();
  }, []);

  return (
    <div>
    
      <nav className="navbar navbar-expand-lg navbar-light  sticky-top" style={{backgroundColor : "#222"}}>
        <a className="navbar-brand" href="/" style={{fontSize: "34px",
        color: 'white',
          marginLeft: "1rem" }}>
          Codigo
        </a>
        <button
        style={{
          backgroundColor: '#d2d1d1',
         
        }}
          className="navbar-toggler custom-button"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNavDropdown" style={{ flexDirection: 'column' }}>
          <ul className="nav shriti">
            {category.map((elem) => (
              <li className="nav-item _61361b4c" key={elem.id}>
                <div className="dropdown a6e85973">
                  <button
                    style={{
                      fontFamily: 'Lora , serif',
                      fontWeight: 'bolder',
                      fontSize: '21px',
                      color : "white"                 
                    }}
                    className="btn main-tag a6e85973"
                   
                    type="button"
                    id={`dropdown-${elem.id}`}
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    onClick={() => handleButtonClick(elem.id)}
                  >
                    {elem.name}
                  </button>
                  <ul className="dropdown-menu" aria-labelledby={`dropdown-${elem.id}`} style={{    fontFamily: 'Lora , serif'}}>
                    {elem.subcategorylist.map((elem) => (
                      <li key={elem.id}>
                        <button style={{    fontFamily: 'Lora , serif'}} className="dropdown-item .dropdown-item1 hover" onClick={() => handleButtonClick(elem.id)}>
                          {elem.name}
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </div>
  );
  
};

export { Header };
