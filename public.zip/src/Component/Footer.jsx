import React from 'react'
import './footer.css'
import { Link } from 'react-router-dom'
import { BsFacebook } from "react-icons/fa";
const Footer = () => {
  return (
    <div className='footer'>
    <footer className='_9c0ddc6d' style={{}}>
      <div className="container">
        <div className="row">
        <div className="col-lg-12 col-sm-12">
        <hr />
        <h1>Codigo</h1></div>
         
         <div className="col-lg-6 col-sm-12">
         <br />
         
        
          <p className='_51f6fc5b'>Codigo is the product recommendation service from The New York Times. Our journalists combine independent research with (occasionally) over-the-top testing so you can make quick and confident buying decisions. Whether it’s finding great products or discovering helpful advice, we’ll help you get it right (the first time).</p>
         </div>

         <div className="col-lg-3 col-sm-12">
         <br />
           <ul className='e9cc76f4' style={{display: 'flex'
           , flexFlow: 'column', textAlign: '-webkit-center'}}>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>About Blog Post</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Our Team</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Staff demographics</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Jobs at Blog Post</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Contact us</Link>
            </li>
           </ul>
         </div>
         <div className="col-lg-3 col-sm-12">
         <br />
           <ul className='e9cc76f4' style={{display: 'flex'
           , flexFlow: 'column' , textAlign: '-webkit-center'}}>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Deals</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Blogs</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Newsletter</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>Lists</Link>
            </li>
            <li className='_58e84260'>
            <Link to="/" className='_9d9727a4'>About Us</Link>
            </li>
           </ul>
         </div>
        </div>
        <div className="row">
         <div className="col-lg-12 col-sm-12" >
        <div className='icons'>
        <i class="fa-brands fa-facebook fa-lg" style={{color: '#ffffff'}}></i>&nbsp;
        <i class="fa-brands fa-twitter fa-lg" style={{color: '#ffffff'}}></i>&nbsp;
        <i class="fa-brands fa-instagram fa-lg" style={{color: '#ffffff'}}></i>&nbsp;
        <i class="fa-brands fa-google fa-lg" style={{color: '#ffffff'}}></i>&nbsp;
        </div>
         </div>
         <br />
         <br />
         
         <div className="row">
        <div className="col-lg-8 col-sm-12">
          <div className="link">
            <ul className='_9d9727a42'>
                <li>privacy Policy</li>&nbsp;|&nbsp;
                <li>Terms Of used</li>&nbsp;|&nbsp;
                <li>Cookie Policy</li>&nbsp;|&nbsp;
                <li>Patnership & Advertishing</li>
            </ul>
          </div>
        </div>
         <div className="col-lg-12 col-sm-12">
         <p style={{textAlign: 'center'}}>@2023 Copyrigth By : Codigo & created by : Mahesh Solanki  </p>
         </div> 
         </div>
        </div>
      </div>
      </footer>
    </div>
  )
}

export { Footer }
