import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { Footer } from './Footer';

import './home.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import photo from '../img/img.jpg';
import { Header2 } from './Header2';
import backendurl from '../Backend';


const Policy = () => {

  const navigate = useNavigate()
    const [data, setData] = useState([]);
    const [category, setCategory] = useState([]);
  
    const fetchAllBooks = async () => {
      try {
        const res = await axios.get( backendurl +'/getactivecategory');
        setCategory(res.data);
        console.log(res.data);
      } catch (err) {
        console.log(err);
      }
    };
  
    const fetchAllPostData = async () => {
      try {
        const res = await axios.get( backendurl + '/posted');
        setData(res.data.data);
        console.log(res.data.data);
      } catch (err) {
        console.log(err);
      }
    };
     
  const handleButtonClick = (id) => { 
    const Cateid = id;
    console.log("category id is the", Cateid)

   
    navigate(`/Category/${Cateid}`);

  }

  const handleButtonClick1 = (id) => {
    const Subcateid = id;
    console.log("subcategory id is the", Subcateid);
  
    navigate(`/Category/${Subcateid}`);
  };
  
  
  
    useEffect(() => {   
      fetchAllBooks();
      fetchAllPostData();
    }, []);
  
    return (
      <>
        <Header2 className = "" categories={category} /> {/* Pass the 'category' state to the Navbar component */}
        <div >

          <div className="container" style={{marginTop: '31px',
            marginBottom: '31px'}}>
          
            <div className="col-12">
              <p className="text-center " 
              style={{backgroundColor : "#d5d5d5;" ,   fontWeight: '800'
              ,fontSize: '18px'
            }}>
                We independently review everything we recommend. When you buy
                through our links, we may earn a commission.
                <a href="/policy" style={{color:'red'}}>Learn More</a>
              </p>
            </div>
          </div>
          <div className='about'>
           <div className="container">
          <div className='row'>
           <div className="col-12" style={{
            textAlign: 'center'}}>
            <h1 className='title'>About Us!</h1>
            <p className='content font-size' style={{fontSize:'26px'}}>Wirecutter’s mission is to recommend what really matters. Each year, we independently test and review thousands of products to help you find just what you need. Our goal is to save you time and eliminate the stress of shopping, whether you’re looking for everyday gear or gifts for loved ones.</p>
            <p className='content font-size' style={{fontSize:'26px'}}>We strive to be the most trusted product recommendation service around, and we work with total editorial independence. We won’t post a recommendation unless our writers and editors have deemed something the best through rigorous reporting and testing.

            Wirecutter was founded in September 2011 and acquired by The New York Times Company in October 2016. We earn money through subscriptions and various affiliate marketing programs. That means we may get paid commissions on products purchased through our links to retailer sites. However, we recommend products based on our independent research, analysis, interviews, and testing. There’s no incentive for us to pick inferior products or to respond to pressure from manufacturers—in fact, it’s quite the opposite. If a reader returns their purchase because they’re dissatisfied or the recommendation is bad, 
           </p>
            <br />
            <p className='content font-size' style={{fontSize:'26px'}}>
            we make no affiliate commission. We think that’s a pretty fair system that keeps us committed to serving our readers first.<br /> And of course, the decisions we make regarding the products we feature on our site are always driven by editorial and product testing standards, not by affiliate deals or advertising relationships.
           <br/>
            Our reviews take weeks or months of research and years of experience. In addition to relying on our own expertise, we gather interviews and data from the best sources around, including engineers, scientists, designers, and innumerable subject-matter experts, ranging from barbers to cat café staff (and residents) to cornhole champions. And we pore over customer reviews to find out what matters to real people who already own and use the things we’re assessing. In a world where overpriced, top-of-the-line models loaded with junk features are often seen as the gold standard, we aim to recommend high-quality things that warrant their price and don’t push extra features you’ll rarely use.
            
            </p>
            <div className='a9740e1f'>
            <img src={photo} alt="Description" style={{width: '100%'  
             , height: '100%'}} />
          </div>
          <div>
          <p className='content font-size' style={{fontSize:'26px'}}>
          we make no affiliate commission. We think that’s a pretty fair system that keeps us committed to serving our readers first.<br /> And of course, the decisions we make regarding the products we feature on our site are always driven by editorial and product testing standards, not by affiliate deals or advertising relationships.
         <br/>
          Our reviews take weeks or months of research and years of experience. In addition to relying on our own expertise, we gather interviews and data from the best sources around, including engineers, scientists, designers, and innumerable subject-matter experts, ranging from barbers to cat café staff (and residents) to cornhole champions. And we pore over customer reviews to find out what matters to real people who already own and use the things we’re assessing. In a world where overpriced, top-of-the-line models loaded with junk features are often seen as the gold standard, we aim to recommend high-quality things that warrant their price and don’t push extra features you’ll rarely use.
          
          </p></div>
           </div>
           </div>
           </div>
          </div>
        </div>
        <br />
        <Footer />
      </>
    );
}

export { Policy } 
