import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Header } from './Header';
import { Link , useNavigate } from 'react-router-dom';
import { Footer } from './Footer';
import play from "../img/Play-Quizzes (3).jpg"
import moment from 'moment';

import './home.css';
import 'bootstrap/dist/css/bootstrap.min.css';

import backendurl from '../Backend';

const Home = () => {
  const [data, setData] = useState([]);
  const [category, setCategory] = useState([]);
  const [title, setTitle] = useState([]);
  const [deal, setDeal] = useState([]);
  const [card, setCard] = useState([]);
  const [cateMi, setCateMi] = useState([]);
  const [xiaomi, setXiaomi] = useState([]);
  const [lenovo, setLenovo] = useState([])
  const [samsung, setSam] = useState([]);


  const navigate = useNavigate();

  const fetchAllBooks = async () => {
  try {
    const res = await axios.get(backendurl + '/getactivecategory');
    setCategory(res.data);
    console.log(res.data);
  } catch (err) {
    console.log(err);
  }
};


  const fetchAllPostData = async () => {
    try {
      const res = await axios.get(backendurl + '/postedUser');
      setData(res.data.data);
      console.log(res.data.data);
    } catch (err) {
      console.log(err);
    }
  };

  const fetchTitle = async() => {
    try{
       const res = await axios.get(backendurl + '/title');
        setTitle(res.data.data);
     }catch(err) {
      console.log(err)
    }
}
  console.log('tit is the ',title)

  const fetchDeals = async () => {
    try{
      const res = await axios.get(backendurl + '/deals');
      console.log("data is the deal",res.data)
      setDeal(res.data.data)
    }catch(err) {
      console.log(err)
    }
  }
 console.log('deals is the',deal)

 const fetchCard = async () => {
  try{
   const res = await axios.get(backendurl + '/card');
   console.log(res)
   setCard(res.data.data);
 
  }catch(err) {
    console.log(err)
  }
 }
 console.log("card details is the ",card)

const fetchMI = async() => {
  try{
    const res = await axios.get(backendurl + '/mi');
    console.log(res)
    setCateMi(res.data.data);

  }catch(Err){
    console.log(Err)
  }
}
console.log("MI is the",cateMi)

const fetchXiaomi = async() => {
 try{
   const res = await axios.get(backendurl + '/xiaomi')
   setXiaomi(res.data.data)
 }catch(err) {
  console.log(err)
 }

}

 const fetchLenovo = async() => {
  try{
   const res = await axios.get(backendurl + '/lenovo')
   setLenovo(res.data.data);

  }catch(err) {
    console.log(err)
  }
 }
 console.log("lenovo data is the",lenovo)


 const fetchSam = async() => {
  try{
    const res = await axios.get(backendurl + '/samsung')
    setSam(res.data.data)
  }catch(err){
    console.log(err)
  }
 }

  useEffect(() => {
    fetchAllBooks();
    fetchAllPostData();
    fetchTitle();
    fetchDeals();
    fetchCard();
    fetchMI();
    fetchXiaomi();
    fetchLenovo();
    fetchSam();
  }, []);

  const handleShowFullBlog = async (blogId) => {
    // Open the first link in a new tab/window
    // window.open('https://948.win.qureka.com', '_blank');
  
    // Wait for a short delay to give the link enough time to open
    await new Promise(resolve => setTimeout(resolve, 1000));
  
    // After the delay, navigate to the specific blog without a full page reload
    const postid = blogId;
    console.log("post id is the", postid);
    navigate(`/post/${postid}`);
  
    // Optionally, scroll to the top of the page
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
  

//the latest news

  const handleUrl = () => {
    //link add krva mate 
    // window.location.href = 'https://948.win.qureka.com';
    // window.location.href = 'https://948.win.qureka.com';
  }
  

  return (
    <>
    <div className="sticky-top">
    <Header className="my-5 " categories={category} /> {/* Pass the 'category' state to the Navbar component */}
  </div> {/* Pass the 'category' state to the Navbar component */}
      <div className='top1'>
      
        <div className="container">
          <div className="col-12">
            <p className="ii text-center my-5 font-size tt" style={{fontWeight: '700'}}>
              We independently review everything we recommend. When you buy
              through our links, we may earn a commission.
              <a href="/policy" style={{color : 'red'}}>Learn More</a>
            </p>
          </div>
        </div>
        <div>
          <div>
            <div className="container">
              <div className="row">
               <div className="col-lg-2 col-sm-12">
                <h1 className='title2 sub'>The latest</h1>
                <div className='tit titfs hover dcd' onClick={() => handleUrl()}>
                <div>
                 <h1 className='tit titfs hover sxs' onClick={() => handleUrl()}>Dare to Question, Dare to Know</h1>
                 </div>
                 <br />
                </div>
                <div className='sd'>
                { 
                  title.map((el) => {
                    return (
                      <div className='gf' key={el.id}>
                        <br />
                        <div>
                          <p className='tit titfs hover' onClick={() => handleShowFullBlog(el.id)}>{el.title}</p>
                          <p className='st'>Yesterday</p>
                        </div>
                      </div>
                    );
                  })
                  
                }
                </div>
                <div className='allpost' style={{    marginTop: '50px'}}>
                  
                <Link className='a' to = "/allpost">See Everything... </Link>
                </div>
                
               </div>
                <div className="col-lg-8 col-sm-12">
                  {data.length > 0 ? (
                    data.map((el, i) => (
                      <div key={el.id}>
                        <br />
                        <div className="img"> 
                          <img className='img1 img' onClick={() => handleShowFullBlog(el.id)}
                            
                            src={backendurl + `/uploads/${el.image}`}
                            alt="mahesh"
                          />
                        </div>

                        <br />
                        <h1 className='title margin-top hover qa wqwq' onClick={() => handleShowFullBlog(el.id)}>{el.title}</h1>
                        <h1 className='authorfs' style={{    color: '#5d72e3'}}></h1>
                        <br />
                        <div className='shortdesc'>
                        <p className='shortdesc1  shortdescfs' onClick={() => handleShowFullBlog(el.id)}>{el.shortdesc}</p>
                        </div>
                        <br />
                       
                      </div>
                      
                    ))
                  ) : (
                    <div></div>
                  )}
                 
                  
                  <br />
                </div>
                <div className="col-lg-2 col-sm-12 fe" style={{lineHeight: '35px'}}>
                <h1 className='title2 sub'>Daily Deals </h1>
                <div className='shadow1 hover'>
                 <img className='w-h' src={play} alt="" onClick={() => handleUrl()} />
                 <h1 style={{fontSize: '21px', color: "rgb(0 0 0)"}}  className='tit hover titfs tit2 space' onClick={() => handleUrl()}>Play Quizzies and earn money</h1>

                </div>
                <div className='as'>
                {deal.map((el) => {
                  return (
                    <div className='shadow1' key={el.id}>
                      <img className='w-h ' src={backendurl + `/uploads/${el.image}`} alt="mahesh" onClick={() => handleShowFullBlog(el.id)} />
                      <h1 className='tit hover titfs tit2' onClick={() => handleShowFullBlog(el.id)}>{el.title}</h1>
                     
                    </div>
                  );
                })}
                </div>
                <div className='allpost'>
                  
                <Link className='a' to = "/allpostcard">See All Deals... </Link>
                </div>
                
                </div>
                
              </div>
            </div>
          </div>
        </div>
        <div>
        <div className="container">
        <h1 className='color title4 headingfs  eew '>All Post</h1>
        <p className='our'>Our expert-approved style picks will keep you comfortable all summer long.</p>
        <div className="row">
        {card.length > 0 ? (
          card.map((el, i) => (
            <div className="col-xl-4 col-lg-6 col-md-6 col-sm-12 marbot" key={el.id}>
              <div className="imgDiv shadow1">
                <img
                  className="card-img-top"
                  src={backendurl + `/uploads/${el.image}`}
                  alt={el.title}
                  style={{ width: '408px', height: '292px' }}
                  onClick={() => handleShowFullBlog(el.id)}
                />
              </div>
              <div className="card-body">
                <h5 className="card-title1 text hover qq  catemargin" onClick={() => handleShowFullBlog(el.id)}>{el.title}</h5>
              </div>
            </div>
          ))
        ) : null}
        
      </div>
       </div>
       </div>
       <div className="container margin-top1">
  <h1 className='color title4 headingfs eew'>MI</h1>
  <div className='row top'>
    {/* Render the first data separately */}

    {cateMi.length > 0 && (
      <div className="col-lg-6 col-sm-12" key={cateMi[0]?.id}>
        <div className="image-wrapper shadow1">
          <img className="cateMi my-image img" src={ backendurl + `/uploads/${cateMi[0].image}`} alt="mahesh" onClick={() => handleShowFullBlog(cateMi[0].id)} />
        </div>
        <div className="card-body">
          <div className="sat">
            <p className='cateMishort text1 hover cursor-pointer'  onClick={() => handleShowFullBlog(cateMi[0].id)}>{cateMi[0].title}</p>

            <h1 className='cateMishort date khk'>UPDATED {moment(cateMi[0].date?.toString()).format('DD-MM-YYYY')}</h1>
            <p className='cateMishort '>{cateMi[0].shortdesc}</p>
          </div>
        </div>
      </div>
    )}
    

    
    <div className="small col-lg-6 col-sm-12">
    <div>
      {cateMi.slice(1).map((el) => {
        return (
          
         <ul className='_304a7536'>
          <li className='_5a0546da shadow1' key={el.id}>
           <img className='_2de903d9 _282e2639 img' src={ backendurl + `/uploads/${el.image}`} alt="" onClick={() => handleShowFullBlog(el.id)} />
            <div className='_4d6eda15'>
             <h1 className='_8d515e6d _0295c507 f-s hover ds' onClick={() => handleShowFullBlog(el.id)}>{el.title}</h1>
            <h1 className='_0b184eb5 '> UPDATED {moment(el.date?.toString()).format('DD-MM-YYYY')}</h1>
            <div className='ff7e0523'>
            <p className="fdf">by {el.author}</p>
            
            </div>
            </div>
          </li>
         
         </ul>
        );
      })}
      </div>
    </div>
  </div>
</div>
<br />
 <div className="container">
  <div className="row">
   <div className="col-12">
   <h1 className='color title4 headingfs eew1'>Xiaomi</h1>
   </div>
  </div>
  <div className="row">
        {xiaomi.length > 0 ? (
          xiaomi.map((el, i) => (
            <div className="col-lg-4 col-md-6 col-sm-12 marbot" key={el.id}>
              <div className=" shadow1">
                <img
                  className="card-img-top"
                  src={ backendurl + `/uploads/${el.image}`}
                  alt={el.title}
                  style={{ width: '408px', height: '292px' }}
                  onClick={() => handleShowFullBlog(el.id)}
                />
                <div className="card-body">
                  <h5 className="card-title text tit catemargin hover cursor-pointer" onClick={() => handleShowFullBlog(el.id)}>{el.title}</h5>
                 
                </div>
              </div>
            </div>
          ))
        ) : null}
      </div>
 </div>

<br />
<br />
 <div className="container">
  <div className="row">
   <div className="col-lg-12">
   <h1 className='color title4 headingfs eew2'>Lenovo</h1>
   </div>
  
   <div className='row top'>
   {/* Render the first data separately */}

   {lenovo.length > 0 && (
    <div className="col-lg-6 col-sm-12" key={lenovo[0]?.id}>
    <div className="image-wrapper shadow1">
      <img className="cateMi img my-image" src={ backendurl + `/uploads/${lenovo[0].image}`} alt="mahesh" onClick={() => handleShowFullBlog(cateMi[0].id)} />
    </div>
    <div className="card-body">
      <div className="sat">
        <p className='cateMishort text1 hover cursor-pointer' onClick={() => handleShowFullBlog(cateMi[0].id)} >{lenovo[0].title}</p>
       
        <h1 className='cateMishort date khk'>UPDATED {moment(lenovo[0].date?.toString()).format('DD-MM-YYYY')}</h1>
        <p className='cateMishort '>{lenovo[0].shortdesc}</p>
      </div>
    </div>
  </div>
)}


   
   <div className="small col-lg-6 col-sm-12 vcv">
   <div>
     {lenovo.slice(1).map((el) => {
       return (
         
        <ul className='_304a7536'>
         <li className='_5a0546da shadow1' key={el.id}>
          <img className='_2de903d9 img _282e2639' src={ backendurl + `/uploads/${el.image}`} alt="" onClick={() => handleShowFullBlog(el.id)}  />
           <div className='_4d6eda15'>
            <h1 className='_8d515e6d _0295c507 hover f-s ds cursor-pointer ' onClick={() => handleShowFullBlog(el.id)} >{el.title}</h1>
           <h1 className='_0b184eb5 '> UPDATED {moment(el.date?.toString()).format('DD-MM-YYYY')}</h1>
           <div className='ff7e0523'>
           <p className="fdf">by {el.author}</p>
           
           </div>
           </div>
         </li>

        </ul>
       );
     })}
     </div>
   </div>
 </div>
   
  </div>
 </div>
<br />
<br />
 <div className="container">
  <div className="row">
   <div className="col-12">
   <h1 className='color title4 headingfs eew3'>Samsung</h1>
   </div>
  </div>
  <div className="row xxx">
  {samsung.length > 0 ? (
    samsung.map((el, i) => (
      <div className="col-lg-4 col-md-6 col-sm-12 marbot" key={el.id}>
        <div className="shadow1">
          <img
            className="card-img-top lll"
            src={ backendurl + `/uploads/${el.image}`}
            alt={el.title}
            style={{ width: '408px', height: '292px' }}
            onClick={() => handleShowFullBlog(el.id)}
          />
          <div className="card-body">
            <h5 className="card-title text catemargin hover cursor-pointer" onClick={() => handleShowFullBlog(el.id)}>{el.title}</h5>
           
          </div>
        </div>
      </div>
    ))
  ) : null}
      </div>
 </div>

    <br />
    <br />    
    </div>
      
      <br />
      <Footer />
    </>
  );
};

export { Home };
