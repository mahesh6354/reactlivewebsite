import React, { useEffect, useState } from 'react';
import { Navbar } from './Navbar';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './alllpost.css';
import moment from 'moment';
import { Footer } from './Footer';
import { Header2 } from './Header2';
import backendurl from '../Backend';

const AllPost = () => {
  const [allpost, setAllPost] = useState([]);
  const [category, setCategory] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const navigate = useNavigate();



  const fetchAllCategories = async () => {
    try {
      const res = await axios.get( backendurl + '/getactivecategory');
      setCategory(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const fetchAllPost = async () => {
    try {
      const res = await axios.get( backendurl +  '/post', {
        params: {
          page: currentPage,
          pageSize: 12,
        },
      });
      setAllPost(res.data.results);
      setTotalPages(res.data.totalPages);
    } catch (Err) {
      console.log(Err);
    }
  };

  const handleButtonClick = (id) => {
    navigate(`/Category/${id}`);
  };

  const handleShowFullBlog = (blogId) => {
    navigate(`/post/${blogId}`);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFirstPage = () => {
    setCurrentPage(1);
  };

  const handleLastPage = () => {
    setCurrentPage(totalPages);
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    fetchAllPost();
    fetchAllCategories();
  }, [currentPage]);

  return (
    <>
    <div className="sticky-top">
    <Header2 className="my-5 " categories={category} /> {/* Pass the 'category' state to the Navbar component */}
  </div>

      <div className="container">
        <div className="text-center my-5 font-size">
          We independently review everything we recommend. When you buy through our links, we may earn a commission.
          <Link to="/policy" style={{color: "red"}}>Learn More</Link>
        </div>
      </div>

      <div className="container">
        <div className="row">
          <div className="col-lg-12 col-sm-12 title">All blog posts</div>
        </div>
      </div>

      <div className="container">
        <div className="row" style={{ marginTop: '30px' }}>
          <div className="col-1"></div>
          <div className="col-lg-10">
            {allpost.map((el) => (
               
                    <ul className='_87ff1abb'>
                        <li className='_5e2e1b57'>
                        <article
                         className='_1b3715bf'>
                         <div className='d09782a1'>
                         <a className='_4dd6f66d'>
                         <div className='_282e2639'>
                           <img className='width' src={ backendurl + `/uploads/${el.image}`} alt="" width="120" height="80" onClick={() => handleShowFullBlog(el.id)}  />
                         </div>
                         </a>
                         </div>
                           <div className='_8cee0047'>
                           <h3 className='ed62fae4' onClick={() => handleShowFullBlog(el.id)} > {el.title}</h3>
                           <p className='d5fb4b49'>
                           <time className='_0b184eb5 '>UPDATED {moment(el.date?.toString()).format('DD-MM-YYYY')} </time>
                           <p className="kk" onClick={() => handleShowFullBlog(el.id)}>{el.shortdesc}</p>
                           <br />                  
                           </p> 
                           </div>
                         </article>
                        </li>
                    </ul>
            ))}
          </div>
        </div>
      </div>

      <div className="container">
        <div className="row">
          <div className="col-12 d-flex justify-content-center mt-5">
            <button
              className="btn btn-light me-2"
              disabled={currentPage <= 1}
              onClick={handleFirstPage}
            >
              First
            </button>
            <button
              className="btn btn-light me-2"
              disabled={currentPage <= 1}
              onClick={handlePreviousPage}
            >
              Previous
            </button>
            {Array.from({ length: totalPages }, (_, index) => index + 1).map((pageNumber) => (
              <button
                key={pageNumber}
                className={`btn btn-light me-2 ${pageNumber === currentPage ? 'active' : ''}`}
                onClick={() => setCurrentPage(pageNumber)}
              >
                {pageNumber}
              </button>
            ))}
            <button
              className="btn btn-light me-2"
              disabled={currentPage >= totalPages}
              onClick={handleNextPage}
            >
              Next
            </button>
            <button
              className="btn btn-light me-2"
              disabled={currentPage >= totalPages}
              onClick={handleLastPage}
            >
              Last
            </button>
          </div>
        </div>
        
      </div>
      <div style={{ marginTop: '20px'}}>
         <Footer />
        </div>
    </>
  );
};

export { AllPost };
