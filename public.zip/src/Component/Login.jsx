import React from 'react' 

const Login = () => { 
	return(
        <>
       <div>hii User !</div>
        </>  
          )
    }
export { Login }