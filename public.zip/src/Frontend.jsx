// localhost url
//const frontendurl = 'http://192.168.1.15:3000';

// live server url
const frontendurl = 'http://quokkka.app';

export default frontendurl;