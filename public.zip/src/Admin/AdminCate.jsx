import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './main.css';
import moment from 'moment';
import backendurl from '../Backend';

const AdminCate = () => {
  const [allpost, setAllPost] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

 

  const fetchAllPost = async () => {
    try {
      const res = await axios.get(backendurl + '/admincate', {
        params: {
          page: currentPage,
          pageSize: 12,
        },
      });
      setAllPost(res.data.results);
      setTotalPages(res.data.totalPages);
    } catch (Err) {
      // console.log(Err);
    }
  };

  const handleFirstPage = () => {
    setCurrentPage(1);
  };

  const handleLastPage = () => {
    setCurrentPage(totalPages);
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleDelete = async (id) => {
    // console.log(id);
    try {
      await axios.delete(backendurl + `/admincate/${id}`);
      window.location.reload();
    } catch (err) {
      // console.log(err);
    }
  };

  useEffect(() => {
    fetchAllPost();
  }, [currentPage]);

  return (
    <>
      <div>
        <nav className="navbar navbar-expand-lg navbar-light vf p-3">
          <div className="d-flex col-12 col-md-3 col-lg-2 flex-wrap flex-md-nowrap justify-content-between">
            <a className="navbar-brand" href="/">
              Codigo
            </a>
            <button
              className="navbar-toggler d-md-none collapsed mb-3"
              type="button"
              data-toggle="collapse"
              data-target="#sidebar"
              aria-controls="sidebar"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
          </div>
        </nav>
        <div className="container-fluid">
          <div className="row">
            <nav id="sidebar" className="col-md-3 col-lg-2 d-md-block sidebar collapse">
              <div className="position-sticky pt-md-5">
                <ul className="nav flex-column">
                  <li className="nav-item">
                    <a className="nav-link active" aria-current="page" href="/adminpanel">
                      <span className="ml-2">Home</span>
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="/admincate">
                      <span className="ml-2">Category</span>
                    </a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" href="/viewpost">
                      <span className="ml-2">Posts</span>
                    </a>
                  </li>
                  <li className='utyu'>
                  <a className="nav-link" href="/admin">
                  <span className="ml-2">logout</span>
                </a> </li>
                  {/* Add more sidebar items */}
                </ul>
              </div>
            </nav>
            <main className="col-md-9 col-lg-10 dc">
              <div className="container">
                <div className="row">
                  <div className="col">
                    <h1 style={{ textAlign: '-webkit-center' }}>Welcome To Category Page</h1>
                    <br />
                    <br />
                    <div className="title">
                      <div
                        className="d-flex flex-wrap justify-content-between align-items-center"
                        style={{ marginTop: '10px' }}
                      >
                        <h1 className="dis">Category</h1>
                        <button className="btn btn-success">
                          <Link className="bt" to="/category">
                            <span className="plus-icon">➕</span>
                          </Link>
                        </button>
                      </div>
                    </div>
                    <br />

                    <table className="table">
                      <thead>
                        <tr>
                          <th>Category ID</th>
                          <th>Category Name</th>
                          <th>Category Parent ID</th>
                          <th>Home</th>
                          <th>Date</th>
                          <th>Operation</th>
                          
                        </tr>
                      </thead>
                      <tbody>
                        {allpost.map((el, i) => (
                          <tr key={el.id}>
                            <td>{el.id}</td>
                            <td>{el.title}</td>
                            <td>{el.parentid}</td>
                            <td>{el.catecheck}</td>
                            <td>{moment(el.createdAt).format('YYYY-MM-DD')}</td>
                            <td className='tftf'>
                              <button className="btn btn-secondary">
                                <Link className="bt" to={`/edit/${el.id}`}>
                                  Update
                                </Link>
                              </button>
                              &nbsp; <button onClick={() => handleDelete(el.id)} className="btn btn-primary">
                                Delete
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="row">
                  <div className="col-12 d-flex justify-content-center mt-5">
                    <button
                      className="btn btn-light me-2"
                      disabled={currentPage <= 1}
                      onClick={handleFirstPage}
                    >
                      First
                    </button>
                    <button
                      className="btn btn-light me-2"
                      disabled={currentPage <= 1}
                      onClick={handlePreviousPage}
                    >
                      Previous
                    </button>
                    {Array.from({ length: totalPages }, (_, index) => index + 1).map((pageNumber) => (
                      <button
                        key={pageNumber}
                        className={`btn btn-light me-2 ${pageNumber === currentPage ? 'active' : ''}`}
                        onClick={() => setCurrentPage(pageNumber)}
                      >
                        {pageNumber}
                      </button>
                    ))}
                    <button
                      className="btn btn-light me-2"
                      disabled={currentPage >= totalPages}
                      onClick={handleNextPage}
                    >
                      Next
                    </button>
                    <button
                      className="btn btn-light me-2"
                      disabled={currentPage >= totalPages}
                      onClick={handleLastPage}
                    >
                      Last
                    </button>
                  </div>
                </div>
              </div>
            </main>
          </div>
        </div>
      </div>
    </>
  );
};

export { AdminCate };
