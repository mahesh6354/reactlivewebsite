import React, { useEffect } from 'react';
import img from '../img/codigologo.png';
import '../Admin/main.css';
import { Link } from 'react-router-dom';

const AdminPanel = () => {

 
  return (
    <>
    <div className='rte'>
      <nav className="navbar navbar-expand-lg navbar-light vf p-3">
        <div className="d-flex col-12 col-md-3 col-lg-2  flex-wrap flex-md-nowrap justify-content-between">
          <a className="navbar-brand" href="/adminpanel">
            Codigo
          </a>
          
          <button
            className="navbar-toggler d-md-none collapsed mb-3"
            type="button"
            data-toggle="collapse"
            data-target="#sidebar"
            aria-controls="sidebar"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
         
        </div>
          
      </nav>
    
      <div className="container-fluid">
        <div className="row">
          <nav
            id="sidebar"
            className="col-md-3 col-lg-2 d-md-block sidebar collapse"
          >
            <div className="position-sticky pt-md-5">
              <ul className="nav flex-column">
                <li className="nav-item">
                  <Link className="nav-link active"  to="/adminpanel" >
                    <span className="ml-2">Home</span>
                  </Link>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/admincate">
                    <span className="ml-2">Category</span>
                  </a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="/viewpost">
                    <span className="ml-2">Posts</span>
                  </a>
                </li>
                <li className='utyu'>
                <a className="nav-link" href="/admin">
                <span className="ml-2">logout</span>
              </a> </li>


               
                {/* Add more sidebar items */}
              </ul>
            </div>
          </nav>
          <main className="col-md-9 col-lg-10 dc">
            <div className="container">
              <div className="row">
                <div className="col-lg-12 col-md-12 col-sm-12">
                  <h1 className='tara'>Hello <marquee className="asas"
                   width="20%" direction="up" height="81px">
                 Admin
                  </marquee>  <br />
                  Welcome To Admin Panel 😃</h1>
                  {/* Add your admin panel content here */}
                </div>
                
              </div>
            </div>
          </main>
        </div>
      </div>
      </div>
    </>
  );
};

export { AdminPanel };
